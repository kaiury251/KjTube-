plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.kj.tube"
    compileSdk = 34

    defaultConfig {
        minSdk = 24
        targetSdk = 34
        versionCode = 2
        versionName = "2.0"
    }

    flavorDimensions += "app"
    productFlavors {
        create("videos") {
            dimension = "app"
            applicationId = "com.kj.videos"
            resValue("string", "app_name", "KJ Vídeos")
            buildConfigField("String", "APP_MODE", "\"VIDEO\"")
        }
        create("music") {
            dimension = "app"
            applicationId = "com.kj.music"
            resValue("string", "app_name", "KJ Music")
            buildConfigField("String", "APP_MODE", "\"MUSIC\"")
        }
    }

    buildFeatures { buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
}
