plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.kj.tube"
    compileSdk = 34

    defaultConfig {
        minSdk = 24
        targetSdk = 34
        versionCode = 3
        versionName = "2.1"
    }

    flavorDimensions += "app"
    productFlavors {
        create("videos") {
            dimension = "app"
            applicationId = "com.kj.videos"
            resValue("string", "app_name", "KJ Vídeos")
            buildConfigField("String", "APP_MODE", "\"VIDEO\"")
        }
        create("music") {
            dimension = "app"
            applicationId = "com.kj.music"
            resValue("string", "app_name", "KJ Music")
            buildConfigField("String", "APP_MODE", "\"MUSIC\"")
        }
    }

    val youtubeApiKey = (project.findProperty("YOUTUBE_API_KEY") as String?) ?: ""
    buildFeatures { buildConfig = true }
    defaultConfig { buildConfigField("String", "YOUTUBE_API_KEY", "\"$youtubeApiKey\"") }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("com.google.android.gms:play-services-auth:21.3.0")
}
