package com.kj.tube

import android.webkit.CookieManager
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest

data class Item(val id: String, val title: String, val sub: String, val thumb: String?)
data class Page(val items: List<Item>, val token: String?)

/** Acessa a API interna do YouTube / YouTube Music usando a sessão da conta vinculada (cookies do WebView). */
object Yt {
    const val UA = "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 " +
        "(KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
    private const val FILTER_VIDEOS = "EgIQAQ=="
    private const val FILTER_SONGS = "EgWKAQIIAWoKEAkQBRAKEAMQBA=="

    private val http = OkHttpClient()
    private val jsonType = "application/json".toMediaType()
    private var webVer: String? = null
    private var musicVer: String? = null

    fun isLinked(): Boolean =
        (CookieManager.getInstance().getCookie("https://www.youtube.com") ?: "").contains("SAPISID=")

    private fun origin(music: Boolean) =
        if (music) "https://music.youtube.com" else "https://www.youtube.com"

    private fun version(music: Boolean): String {
        (if (music) musicVer else webVer)?.let { return it }
        val fallback = if (music) "1.20251103.01.00" else "2.20251103.01.00"
        val v = try {
            val html = http.newCall(
                Request.Builder().url(origin(music) + "/").header("User-Agent", UA).build()
            ).execute().use { it.body?.string() ?: "" }
            Regex("\"INNERTUBE_CONTEXT_CLIENT_VERSION\":\"([^\"]+)\"").find(html)?.groupValues?.get(1) ?: fallback
        } catch (e: Exception) {
            fallback
        }
        if (music) musicVer = v else webVer = v
        return v
    }

    private fun auth(ck: String, origin: String): String? {
        val s = ck.split(";").map { it.trim() }
            .firstOrNull { it.startsWith("SAPISID=") }?.removePrefix("SAPISID=") ?: return null
        val ts = System.currentTimeMillis() / 1000
        val sha = MessageDigest.getInstance("SHA-1").digest("$ts $s $origin".toByteArray())
            .joinToString("") { "%02x".format(it) }
        return "SAPISIDHASH ${ts}_$sha"
    }

    private fun call(music: Boolean, endpoint: String, body: JSONObject): JSONObject {
        val o = origin(music)
        val v = version(music)
        val client = JSONObject()
            .put("clientName", if (music) "WEB_REMIX" else "WEB")
            .put("clientVersion", v).put("hl", "pt").put("gl", "BR")
        body.put("context", JSONObject().put("client", client))
        val ck = CookieManager.getInstance().getCookie(o) ?: ""
        val rb = Request.Builder().url("$o/youtubei/v1/$endpoint?prettyPrint=false")
            .post(body.toString().toRequestBody(jsonType))
            .header("User-Agent", UA).header("Origin", o).header("Referer", "$o/")
            .header("X-Origin", o).header("X-Goog-AuthUser", "0")
            .header("X-YouTube-Client-Name", if (music) "67" else "1")
            .header("X-YouTube-Client-Version", v)
        if (ck.isNotEmpty()) {
            rb.header("Cookie", ck)
            auth(ck, o)?.let { rb.header("Authorization", it) }
        }
        http.newCall(rb.build()).execute().use { r ->
            val text = r.body?.string() ?: ""
            if (!r.isSuccessful) throw Exception("HTTP ${r.code}")
            return JSONObject(text)
        }
    }

    // ---------- leitura do JSON ----------
    private fun dig(j: Any?, vararg path: Any): Any? {
        var cur = j
        for (p in path) {
            cur = when {
                p is String && cur is JSONObject -> cur.opt(p)
                p is Int && cur is JSONArray -> cur.opt(p)
                else -> return null
            }
        }
        return cur
    }

    private fun str(j: Any?, vararg path: Any): String? = dig(j, *path) as? String

    private fun textOf(t: Any?): String? =
        (dig(t, "simpleText") as? String) ?: (dig(t, "runs", 0, "text") as? String)

    private fun lastThumb(arr: Any?): String? {
        val a = arr as? JSONArray ?: return null
        if (a.length() == 0) return null
        var u = a.optJSONObject(a.length() - 1)?.optString("url")
        if (u != null && u.startsWith("//")) u = "https:$u"
        return u
    }

    private fun parseVideo(o: JSONObject): Item? {
        val id = o.optString("videoId")
        if (id.isEmpty()) return null
        val title = textOf(o.opt("title")) ?: return null
        val author = textOf(o.opt("ownerText")) ?: textOf(o.opt("longBylineText"))
            ?: textOf(o.opt("shortBylineText")) ?: ""
        return Item(id, title, author, lastThumb(dig(o, "thumbnail", "thumbnails")))
    }

    private fun parseLockup(o: JSONObject): Item? {
        if (o.optString("contentType") != "LOCKUP_CONTENT_TYPE_VIDEO") return null
        val id = o.optString("contentId")
        if (id.isEmpty()) return null
        val md = dig(o, "metadata", "lockupMetadataViewModel")
        val title = str(md, "title", "content") ?: return null
        val sub = str(md, "metadata", "contentMetadataViewModel", "metadataRows", 0,
            "metadataParts", 0, "text", "content") ?: ""
        val img = dig(o, "contentImage", "thumbnailViewModel", "image", "sources")
            ?: dig(o, "contentImage", "collectionThumbnailViewModel", "primaryThumbnail",
                "thumbnailViewModel", "image", "sources")
        return Item(id, title, sub, lastThumb(img))
    }

    private fun parseMusic(o: JSONObject): Item? {
        val id = str(o, "playlistItemData", "videoId")
            ?: str(o, "overlay", "musicItemThumbnailOverlayRenderer", "content",
                "musicPlayButtonRenderer", "playNavigationEndpoint", "watchEndpoint", "videoId")
            ?: return null
        val title = str(o, "flexColumns", 0, "musicResponsiveListItemFlexColumnRenderer",
            "text", "runs", 0, "text") ?: return null
        val runs = dig(o, "flexColumns", 1, "musicResponsiveListItemFlexColumnRenderer",
            "text", "runs") as? JSONArray
        val sub = buildString {
            if (runs != null) for (i in 0 until runs.length()) append(runs.optJSONObject(i)?.optString("text") ?: "")
        }
        return Item(id, title, sub,
            lastThumb(dig(o, "thumbnail", "musicThumbnailRenderer", "thumbnail", "thumbnails")))
    }

    private fun walk(j: Any?, music: Boolean, out: MutableList<Item>, seen: MutableSet<String>) {
        when (j) {
            is JSONObject -> {
                val keys = j.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    val v = j.opt(k)
                    if (v is JSONObject) {
                        val item = when {
                            !music && k == "videoRenderer" -> parseVideo(v)
                            !music && k == "lockupViewModel" -> parseLockup(v)
                            music && k == "musicResponsiveListItemRenderer" -> parseMusic(v)
                            else -> null
                        }
                        if (item != null) {
                            if (seen.add(item.id)) out.add(item)
                            continue
                        }
                    }
                    walk(v, music, out, seen)
                }
            }
            is JSONArray -> for (i in 0 until j.length()) walk(j.opt(i), music, out, seen)
        }
    }

    private fun collectTokens(j: Any?, out: MutableList<String>) {
        when (j) {
            is JSONObject -> {
                j.optJSONObject("continuationCommand")?.optString("token")
                    ?.takeIf { it.isNotEmpty() }?.let { out.add(it) }
                j.optJSONObject("nextContinuationData")?.optString("continuation")
                    ?.takeIf { it.isNotEmpty() }?.let { out.add(it) }
                val keys = j.keys()
                while (keys.hasNext()) collectTokens(j.opt(keys.next()), out)
            }
            is JSONArray -> for (i in 0 until j.length()) collectTokens(j.opt(i), out)
        }
    }

    private fun parse(music: Boolean, root: JSONObject): Page {
        val items = ArrayList<Item>()
        walk(root, music, items, HashSet())
        val tokens = ArrayList<String>()
        collectTokens(root, tokens)
        return Page(items, tokens.lastOrNull())
    }

    // ---------- API pública ----------
    fun search(q: String, music: Boolean): Page = parse(music,
        call(music, "search", JSONObject().put("query", q)
            .put("params", if (music) FILTER_SONGS else FILTER_VIDEOS)))

    fun searchMore(token: String, music: Boolean): Page =
        parse(music, call(music, "search", JSONObject().put("continuation", token)))

    fun history(music: Boolean): Page = parse(music,
        call(music, "browse", JSONObject().put("browseId", if (music) "FEmusic_history" else "FEhistory")))

    fun historyMore(token: String, music: Boolean): Page =
        parse(music, call(music, "browse", JSONObject().put("continuation", token)))
}
