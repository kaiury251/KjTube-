package com.kj.tube

import android.content.Context
import java.security.MessageDigest

/** Guarda os cookies da conta Google/YouTube vinculada (login pelo WebView). */
object Session {
    private const val PREF = "kj_session"
    @Volatile var cookie: String? = null

    fun load(ctx: Context) {
        cookie = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("cookie", null)
    }

    fun save(ctx: Context, value: String?) {
        cookie = value
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString("cookie", value).apply()
    }

    private fun sapisid(): String? = cookie?.split(";")?.map { it.trim() }
        ?.firstOrNull { it.startsWith("SAPISID=") }?.removePrefix("SAPISID=")

    fun sapisidHash(origin: String): String? {
        val s = sapisid() ?: return null
        val ts = System.currentTimeMillis() / 1000
        val sha = MessageDigest.getInstance("SHA-1")
            .digest("$ts $s $origin".toByteArray())
            .joinToString("") { "%02x".format(it) }
        return "SAPISIDHASH ${ts}_$sha"
    }
}
