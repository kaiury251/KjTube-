package com.kj.tube

import okhttp3.OkHttpClient
import okhttp3.RequestBody.Companion.toRequestBody
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.downloader.Downloader
import org.schabi.newpipe.extractor.downloader.Request
import org.schabi.newpipe.extractor.downloader.Response
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException
import org.schabi.newpipe.extractor.localization.ContentCountry
import org.schabi.newpipe.extractor.localization.Localization
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem

data class Item(
    val title: String,
    val author: String,
    val thumb: String?,
    val url: String,
    val duration: Long
)

data class Resolved(val url: String, val hls: Boolean)

class AppDownloader : Downloader() {
    private val client = OkHttpClient.Builder().build()
    private val ua = "Mozilla/5.0 (Windows NT 10.0; rv:128.0) Gecko/20100101 Firefox/128.0"

    override fun execute(request: Request): Response {
        val method = request.httpMethod()
        val data = request.dataToSend()
        val body = data?.toRequestBody() ?: if (method == "POST") ByteArray(0).toRequestBody() else null
        val builder = okhttp3.Request.Builder().method(method, body).url(request.url())
            .header("User-Agent", ua)
        request.headers().forEach { (k, values) ->
            builder.removeHeader(k)
            values.forEach { builder.addHeader(k, it) }
        }
        val host = try { java.net.URI(request.url()).host ?: "" } catch (e: Exception) { "" }
        val ck = Session.cookie
        if (ck != null && (host.endsWith("youtube.com") || host == "youtubei.googleapis.com")) {
            builder.header("Cookie", ck)
            val clientName = request.headers().entries
                .firstOrNull { it.key.equals("X-YouTube-Client-Name", true) }?.value?.firstOrNull()
            if (clientName == "1" || clientName == "67") {
                val origin = if (host.startsWith("music.")) "https://music.youtube.com" else "https://www.youtube.com"
                Session.sapisidHash(origin)?.let {
                    builder.header("Authorization", it)
                    builder.header("X-Origin", origin)
                    builder.header("X-Goog-AuthUser", "0")
                }
            }
        }
        client.newCall(builder.build()).execute().use { r ->
            if (r.code == 429) throw ReCaptchaException("reCaptcha", request.url())
            return Response(
                r.code, r.message, r.headers.toMultimap(),
                r.body?.string(), r.request.url.toString()
            )
        }
    }
}

object Repo {
    private var started = false

    fun init() {
        if (started) return
        NewPipe.init(AppDownloader(), Localization("pt", "BR"), ContentCountry("BR"))
        started = true
    }

    fun search(query: String, music: Boolean): List<Item> {
        val filter = if (music) "music_songs" else "videos"
        val ex = ServiceList.YouTube.getSearchExtractor(query, listOf(filter), "")
        ex.fetchPage()
        return ex.initialPage.items
            .filterIsInstance<StreamInfoItem>()
            .map {
                Item(
                    it.name, it.uploaderName ?: "",
                    it.thumbnails.lastOrNull()?.url, it.url, it.duration
                )
            }
    }

    fun resolve(url: String, music: Boolean): Resolved {
        val info = StreamInfo.getInfo(url)
        if (music) {
            val a = info.audioStreams.maxByOrNull { it.averageBitrate }
            if (a != null) return Resolved(a.content, false)
        } else {
            val v = info.videoStreams.maxByOrNull { it.height }
            if (v != null) return Resolved(v.content, false)
            if (!info.hlsUrl.isNullOrEmpty()) return Resolved(info.hlsUrl, true)
        }
        val any = info.audioStreams.firstOrNull() ?: error("Nenhum stream disponível")
        return Resolved(any.content, false)
    }
}
