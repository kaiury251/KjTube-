package com.kj.tube

import android.annotation.SuppressLint
import android.app.Application
import android.content.pm.ActivityInfo
import android.graphics.Color as AColor
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream

class TubeVM(app: Application) : AndroidViewModel(app) {
    val music = BuildConfig.APP_MODE == "MUSIC"
    var tab by mutableStateOf(0)
    var linked by mutableStateOf(Yt.isLinked())
    var showLogin by mutableStateOf(false)
    var home by mutableStateOf<List<Item>>(emptyList())
    var homeToken by mutableStateOf<String?>(null)
    var hist by mutableStateOf<List<Item>>(emptyList())
    var histToken by mutableStateOf<String?>(null)
    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var current by mutableStateOf<Item?>(null)
    var playing by mutableStateOf(false)
    var lastQuery = if (music) "músicas mais tocadas" else "em alta brasil"

    var player: WebView? = null
    private var queue: List<Item> = emptyList()
    private var qIndex = -1

    init {
        search(lastQuery)
        if (linked) loadHistory(false)
    }

    private fun load(block: suspend () -> Unit) {
        viewModelScope.launch {
            loading = true; error = null
            try { block() } catch (e: Exception) { error = "Erro: ${e.message}" }
            loading = false
        }
    }

    fun search(q: String, more: Boolean = false) {
        if (q.isBlank()) return
        lastQuery = q
        val t = homeToken
        load {
            val p = withContext(Dispatchers.IO) {
                if (more && t != null) Yt.searchMore(t, music) else Yt.search(q, music)
            }
            home = if (more) home + p.items else p.items
            homeToken = p.token
        }
    }

    fun loadHistory(more: Boolean) {
        val t = histToken
        load {
            val p = withContext(Dispatchers.IO) {
                if (more && t != null) Yt.historyMore(t, music) else Yt.history(music)
            }
            hist = if (more) hist + p.items else p.items
            histToken = p.token
            if (!more && p.items.isEmpty())
                error = "Nenhum item no histórico (ele pode estar pausado ou desativado na conta)."
        }
    }

    fun play(list: List<Item>, index: Int) { queue = list; qIndex = index; startCurrent() }

    private fun startCurrent() {
        val item = queue.getOrNull(qIndex) ?: return
        current = item
        playing = false
        player?.loadUrl("https://m.youtube.com/watch?v=${item.id}")
    }

    fun next() { if (qIndex + 1 < queue.size) { qIndex++; startCurrent() } }
    fun prev() { if (qIndex > 0) { qIndex--; startCurrent() } }
    fun toggle() { player?.evaluateJavascript("window.kjToggle&&window.kjToggle()", null) }

    fun onLoginDone() {
        showLogin = false
        linked = Yt.isLinked()
        if (linked) { loadHistory(false); search(lastQuery) }
    }

    fun logout() {
        CookieManager.getInstance().removeAllCookies { CookieManager.getInstance().flush() }
        linked = false
        hist = emptyList(); histToken = null
        tab = 0
    }
}

class MainActivity : ComponentActivity() {
    private lateinit var vm: TubeVM
    private lateinit var web: WebView
    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null

    private val adHosts = listOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "google-analytics.com", "adservice.google."
    )
    private val adPaths = listOf(
        "/pagead/", "/api/stats/ads", "/ptracking", "/get_midroll_info", "/api/stats/atr"
    )

    private fun isAd(url: String): Boolean {
        val u = Uri.parse(url)
        val host = u.host ?: return false
        if (adHosts.any { host.contains(it) }) return true
        if (host.endsWith("youtube.com") || host.endsWith("googlevideo.com")) {
            val path = u.path ?: ""
            if (adPaths.any { path.contains(it) }) return true
        }
        return false
    }

    private val playerJs = """
(function(){
 if(window.__kj) return; window.__kj=true;
 try{
  Object.defineProperty(document,'hidden',{get:function(){return false}});
  Object.defineProperty(document,'visibilityState',{get:function(){return 'visible'}});
  document.addEventListener('visibilitychange',function(e){e.stopImmediatePropagation();},true);
 }catch(e){}
 var css=document.createElement('style');
 css.textContent='html,body{overflow:hidden!important;background:#000!important}'+
 'ytm-mobile-topbar-renderer,ytm-pivot-bar-renderer,.mobile-topbar-header,ytm-promoted-sparkles-web-renderer,'+
 'ytm-promoted-video-renderer,ytm-companion-ad-renderer,ytm-ad-slot-renderer,ad-slot-renderer,ytd-ad-slot-renderer,'+
 '.ytp-ad-overlay-container,#player-ads,.masthead-ad,ytm-statement-banner-renderer,ytmusic-mealbar-promo-renderer,'+
 'ytm-watch-metadata-app-promo-renderer{display:none!important}';
 document.documentElement.appendChild(css);
 var userPaused=false, last=null, ended=false;
 window.kjToggle=function(){
  var v=document.querySelector('video'); if(!v) return;
  if(v.paused){userPaused=false; v.play();} else {userPaused=true; v.pause();}
 };
 setInterval(function(){
  try{
   var v=document.querySelector('video');
   var ad=document.querySelector('.html5-video-player.ad-showing,.ad-showing,[ad-showing]');
   var skip=document.querySelector('.ytp-skip-ad-button,.ytp-ad-skip-button,.ytp-ad-skip-button-modern,.ytp-ad-skip-button-container button');
   if(skip) skip.click();
   if(!v) return;
   if(ad){
     v.muted=true; v.playbackRate=16;
     if(isFinite(v.duration)&&v.duration>0) v.currentTime=v.duration;
     window.__kjA=true;
   } else {
     if(window.__kjA){ v.muted=false; v.playbackRate=1; window.__kjA=false; }
     if(v.paused&&!userPaused&&!v.ended){ var pr=v.play(); if(pr&&pr.catch) pr.catch(function(){}); }
   }
   var p=!v.paused;
   if(p!==last){ last=p; if(window.KJ&&KJ.state) KJ.state(p); }
   if(v.ended&&!ended){ ended=true; if(window.KJ&&KJ.ended) KJ.ended(); }
   if(!v.ended) ended=false;
  }catch(e){}
 },400);
})();
"""

    inner class Bridge {
        @JavascriptInterface fun ended() { runOnUiThread { vm.next() } }
        @JavascriptInterface fun state(p: Boolean) { runOnUiThread { vm.playing = p } }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun buildPlayer(): WebView {
        val w = WebView(this)
        w.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            userAgentString = Yt.UA
        }
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(w, true)
        }
        w.setBackgroundColor(AColor.BLACK)
        w.addJavascriptInterface(Bridge(), "KJ")
        w.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                if (isAd(request.url.toString()))
                    WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                else null

            override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                view.evaluateJavascript(playerJs, null)
            }

            override fun onPageFinished(view: WebView, url: String?) {
                view.evaluateJavascript(playerJs, null)
                CookieManager.getInstance().flush()
            }
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                if (customView != null) { callback.onCustomViewHidden(); return }
                customView = view
                customCb = callback
                (window.decorView as ViewGroup).addView(view, ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                @Suppress("DEPRECATION")
                window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
            }

            override fun onHideCustomView() { hideCustom() }
        }
        return w
    }

    private fun hideCustom() {
        val v = customView ?: return
        (window.decorView as ViewGroup).removeView(v)
        customView = null
        customCb?.onCustomViewHidden()
        customCb = null
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        vm = ViewModelProvider(this)[TubeVM::class.java]
        window.statusBarColor = AColor.parseColor("#0F0F0F")
        window.navigationBarColor = AColor.parseColor("#0F0F0F")
        web = buildPlayer()
        vm.player = web

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    customView != null -> hideCustom()
                    vm.showLogin -> vm.showLogin = false
                    else -> moveTaskToBack(true)
                }
            }
        })

        setContent {
            val accent = if (vm.music) Color(0xFFB388FF) else Color(0xFFFF3D3D)
            MaterialTheme(colorScheme = darkColorScheme(primary = accent)) {
                Surface(Modifier.fillMaxSize(), color = Color(0xFF0F0F0F)) {
                    if (vm.showLogin) LoginScreen(vm) else TubeScreen(vm, web)
                }
            }
        }
    }

    override fun onDestroy() {
        vm.player = null
        super.onDestroy()
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun LoginScreen(vm: TubeVM) {
    BackHandler { vm.showLogin = false }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Entre na sua conta Google", color = Color.White, modifier = Modifier.weight(1f))
            TextButton(onClick = { vm.showLogin = false }) { Text("Cancelar") }
        }
        AndroidView(modifier = Modifier.fillMaxSize(), factory = { c ->
            var done = false
            WebView(c).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.userAgentString = Yt.UA
                CookieManager.getInstance().setAcceptCookie(true)
                CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView, url: String?) {
                        val host = url?.let { Uri.parse(it).host } ?: return
                        if (!done && host.endsWith("youtube.com")) {
                            val ck = CookieManager.getInstance().getCookie("https://www.youtube.com")
                            if (ck != null && ck.contains("SAPISID=")) {
                                done = true
                                CookieManager.getInstance().flush()
                                vm.onLoginDone()
                            }
                        }
                    }
                }
                loadUrl("https://accounts.google.com/ServiceLogin?service=youtube&hl=pt-BR&continue=" +
                    Uri.encode("https://www.youtube.com/"))
            }
        })
    }
}

@Composable
fun TubeScreen(vm: TubeVM, playerWeb: WebView) {
    var query by remember { mutableStateOf("") }
    val accent = MaterialTheme.colorScheme.primary

    Column(Modifier.fillMaxSize().statusBarsPadding().padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                if (vm.music) "KJ Music" else "KJ Vídeos",
                style = MaterialTheme.typography.headlineSmall,
                color = accent, modifier = Modifier.weight(1f)
            )
            if (!vm.linked) {
                OutlinedButton(onClick = { vm.showLogin = true }) { Text("Vincular conta Google") }
            } else {
                TextButton(onClick = { vm.logout() }) { Text("Conta vinculada • Sair") }
            }
        }
        Row {
            TextButton(onClick = { vm.tab = 0 }) {
                Text("Início", color = if (vm.tab == 0) accent else Color.Gray)
            }
            TextButton(onClick = {
                vm.tab = 1
                if (vm.linked && vm.hist.isEmpty() && !vm.loading) vm.loadHistory(false)
            }) { Text("Histórico", color = if (vm.tab == 1) accent else Color.Gray) }
        }
        if (vm.tab == 0) {
            OutlinedTextField(
                value = query, onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(), singleLine = true,
                placeholder = { Text(if (vm.music) "Buscar músicas" else "Buscar vídeos") },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { vm.search(query) })
            )
            Spacer(Modifier.height(6.dp))
        }

        val cur = vm.current
        if (cur != null) {
            AndroidView(
                modifier = Modifier.fillMaxWidth().height(220.dp),
                factory = { _ ->
                    (playerWeb.parent as? ViewGroup)?.removeView(playerWeb)
                    playerWeb
                }
            )
            Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Text(cur.title, maxLines = 2, overflow = TextOverflow.Ellipsis, color = Color.White)
                Text(cur.sub, color = Color.Gray, style = MaterialTheme.typography.bodySmall, maxLines = 1)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { vm.prev() }) { Text("Anterior") }
                    Button(onClick = { vm.toggle() }) { Text(if (vm.playing) "Pausar" else "Tocar") }
                    TextButton(onClick = { vm.next() }) { Text("Próxima") }
                }
            }
        }

        vm.error?.let { Text(it, color = Color(0xFFFF8A80), modifier = Modifier.padding(vertical = 4.dp)) }
        if (vm.loading) LinearProgressIndicator(Modifier.fillMaxWidth())

        if (vm.tab == 1 && !vm.linked) {
            Spacer(Modifier.height(12.dp))
            Text("Vincule sua conta Google para ver o histórico do " +
                (if (vm.music) "YouTube Music." else "YouTube."), color = Color.Gray)
            Spacer(Modifier.height(8.dp))
            Button(onClick = { vm.showLogin = true }) { Text("Vincular conta Google") }
        } else {
            val list = if (vm.tab == 0) vm.home else vm.hist
            val token = if (vm.tab == 0) vm.homeToken else vm.histToken
            LazyColumn(Modifier.fillMaxSize()) {
                itemsIndexed(list) { i, item ->
                    Row(
                        Modifier.fillMaxWidth().clickable { vm.play(list, i) }.padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AsyncImage(
                            model = item.thumb, contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .then(if (vm.music) Modifier.size(64.dp) else Modifier.width(140.dp).height(80.dp))
                                .clip(RoundedCornerShape(8.dp))
                        )
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(item.title, maxLines = 2, overflow = TextOverflow.Ellipsis, color = Color.White)
                            Text(item.sub, color = Color.Gray, style = MaterialTheme.typography.bodySmall, maxLines = 1)
                        }
                    }
                }
                item {
                    if (token != null && !vm.loading) {
                        TextButton(onClick = {
                            if (vm.tab == 0) vm.search(vm.lastQuery, true) else vm.loadHistory(true)
                        }) { Text("Carregar mais") }
                    }
                }
            }
        }
    }
}
