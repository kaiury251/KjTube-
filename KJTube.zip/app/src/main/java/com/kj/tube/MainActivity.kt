package com.kj.tube

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import java.io.ByteArrayInputStream

class MainActivity : Activity() {

    private val music = BuildConfig.APP_MODE == "MUSIC"
    private val home = if (music) "https://music.youtube.com/" else "https://m.youtube.com/"
    private val accent = if (music) Color.parseColor("#B388FF") else Color.parseColor("#FF3D3D")
    private val ua = "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 " +
        "(KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"

    private lateinit var root: FrameLayout
    private lateinit var web: WebView
    private lateinit var accountBtn: Button
    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null

    private val adHosts = listOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "google-analytics.com", "adservice.google."
    )
    private val adPaths = listOf(
        "/pagead/", "/api/stats/ads", "/ptracking", "/get_midroll_info",
        "/api/stats/atr", "/youtubei/v1/player/ad_break"
    )

    private fun isAd(url: String): Boolean {
        val u = Uri.parse(url)
        val host = u.host ?: return false
        if (adHosts.any { host.contains(it) }) return true
        if (host.endsWith("youtube.com") || host.endsWith("googlevideo.com")) {
            val path = u.path ?: ""
            if (adPaths.any { path.contains(it) }) return true
        }
        return false
    }

    private val adJs = """
(function(){
 if(window.__kj) return; window.__kj=true;
 var css=document.createElement('style');
 css.textContent='ytm-promoted-sparkles-web-renderer,ytm-promoted-video-renderer,ytm-companion-ad-renderer,'+
 'ytm-ad-slot-renderer,ad-slot-renderer,ytd-ad-slot-renderer,ytd-display-ad-renderer,.ytp-ad-overlay-container,'+
 '#player-ads,.masthead-ad,ytm-statement-banner-renderer,ytmusic-mealbar-promo-renderer{display:none!important}';
 document.documentElement.appendChild(css);
 setInterval(function(){
  try{
   var ad=document.querySelector('.html5-video-player.ad-showing,.ad-showing,[ad-showing]');
   var skip=document.querySelector('.ytp-skip-ad-button,.ytp-ad-skip-button,.ytp-ad-skip-button-modern,.ytp-ad-skip-button-container button');
   if(skip) skip.click();
   var v=document.querySelector('video');
   if(ad && v){
     v.muted=true; v.playbackRate=16;
     if(isFinite(v.duration)&&v.duration>0) v.currentTime=v.duration;
     window.__kjA=true;
   } else if(window.__kjA && v){
     v.muted=false; v.playbackRate=1; window.__kjA=false;
   }
  }catch(e){}
 },300);
})();
"""

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#0F0F0F")
        window.navigationBarColor = Color.parseColor("#0F0F0F")

        root = FrameLayout(this).apply { setBackgroundColor(Color.parseColor("#0F0F0F")) }
        val column = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(32, 16, 24, 16)
        }
        val title = TextView(this).apply {
            text = if (music) "KJ Music" else "KJ Vídeos"
            setTextColor(accent)
            textSize = 22f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        header.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        accountBtn = Button(this).apply {
            isAllCaps = false
            setTextColor(accent)
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener { onAccountClick() }
        }
        header.addView(accountBtn, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        column.addView(header)

        web = WebView(this)
        column.addView(web, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(column, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            userAgentString = ua
            loadWithOverviewMode = true
        }
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(web, true)
        }
        web.setBackgroundColor(Color.parseColor("#0F0F0F"))

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView, request: WebResourceRequest
            ): WebResourceResponse? {
                return if (isAd(request.url.toString()))
                    WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                else null
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val scheme = request.url.scheme ?: ""
                if (scheme != "http" && scheme != "https") {
                    try { startActivity(Intent(Intent.ACTION_VIEW, request.url)) } catch (e: Exception) {}
                    return true
                }
                return false
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                view.evaluateJavascript(adJs, null)
            }

            override fun onPageFinished(view: WebView, url: String?) {
                view.evaluateJavascript(adJs, null)
                CookieManager.getInstance().flush()
                updateAccountButton()
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                if (customView != null) { callback.onCustomViewHidden(); return }
                customView = view
                customCb = callback
                root.addView(view, FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                @Suppress("DEPRECATION")
                window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
            }

            override fun onHideCustomView() { hideCustom() }
        }

        updateAccountButton()
        if (savedInstanceState == null) web.loadUrl(home) else web.restoreState(savedInstanceState)
    }

    private fun hideCustom() {
        val v = customView ?: return
        root.removeView(v)
        customView = null
        customCb?.onCustomViewHidden()
        customCb = null
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
    }

    private fun isLinked(): Boolean {
        val ck = CookieManager.getInstance().getCookie("https://www.youtube.com") ?: return false
        return ck.contains("SAPISID=")
    }

    private fun updateAccountButton() {
        accountBtn.text = if (isLinked()) "Conta vinculada • Sair" else "Vincular conta Google"
    }

    private fun onAccountClick() {
        if (isLinked()) {
            CookieManager.getInstance().removeAllCookies {
                CookieManager.getInstance().flush()
                runOnUiThread { updateAccountButton(); web.loadUrl(home) }
            }
        } else {
            web.loadUrl(
                "https://accounts.google.com/ServiceLogin?service=youtube&hl=pt-BR&continue=" +
                    Uri.encode(home)
            )
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            customView != null -> hideCustom()
            web.canGoBack() -> web.goBack()
            else -> @Suppress("DEPRECATION") super.onBackPressed()
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }
}
