package com.kj.tube

import android.app.Application
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class TubeVM(app: Application) : AndroidViewModel(app) {
    val music = BuildConfig.APP_MODE == "MUSIC"
    var items by mutableStateOf<List<Item>>(emptyList())
    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var loginMsg by mutableStateOf<String?>(null)
    var current by mutableStateOf<Item?>(null)
    var playing by mutableStateOf(false)
    var account by mutableStateOf<GoogleSignInAccount?>(null)
    val player: ExoPlayer = ExoPlayer.Builder(app)
        .setMediaSourceFactory(
            DefaultMediaSourceFactory(
                DefaultHttpDataSource.Factory()
                    .setUserAgent("Mozilla/5.0 (Windows NT 10.0; rv:128.0) Gecko/20100101 Firefox/128.0")
                    .setAllowCrossProtocolRedirects(true)
            )
        ).build()

    init {
        Repo.init()
        account = GoogleSignIn.getLastSignedInAccount(app)
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onPlayerError(e: PlaybackException) {
                error = "Erro no player: ${e.errorCodeName}"
            }
        })
        search(if (music) "músicas mais tocadas" else "em alta brasil")
    }

    fun search(q: String) {
        if (q.isBlank()) return
        viewModelScope.launch {
            loading = true; error = null
            try {
                items = withContext(Dispatchers.IO) { Repo.search(q, music) }
            } catch (e: Exception) {
                error = "Erro na busca: ${e.message}"
            }
            loading = false
        }
    }

    fun play(item: Item) {
        current = item
        viewModelScope.launch {
            error = null
            try {
                val r = withContext(Dispatchers.IO) { Repo.resolve(item.url, music) }
                val mi = MediaItem.Builder().setUri(r.url).apply {
                    if (r.hls) setMimeType(MimeTypes.APPLICATION_M3U8)
                }.build()
                player.setMediaItem(mi)
                player.prepare()
                player.playWhenReady = true
            } catch (e: Exception) {
                error = "Não foi possível reproduzir: ${e.message}"
            }
        }
    }

    fun togglePlay() { if (player.isPlaying) player.pause() else player.play() }

    override fun onCleared() { player.release() }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val music = BuildConfig.APP_MODE == "MUSIC"
            val accent = if (music) Color(0xFFB388FF) else Color(0xFFFF3D3D)
            MaterialTheme(colorScheme = darkColorScheme(primary = accent)) {
                Surface(Modifier.fillMaxSize(), color = Color(0xFF0F0F0F)) {
                    TubeScreen()
                }
            }
        }
    }
}

@Composable
fun TubeScreen(vm: TubeVM = viewModel()) {
    val ctx = LocalContext.current
    var query by remember { mutableStateOf("") }
    val gso = remember {
        GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail().requestProfile().build()
    }
    val gClient = remember { GoogleSignIn.getClient(ctx, gso) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        try {
            vm.account = GoogleSignIn.getSignedInAccountFromIntent(res.data)
                .getResult(ApiException::class.java)
            vm.loginMsg = null
        } catch (e: ApiException) {
            vm.loginMsg = if (e.statusCode == 10)
                "Login Google ainda não configurado (código 10). Sem problema: o app funciona sem login."
            else "Login Google falhou (código ${e.statusCode}). O app funciona sem login."
        }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                if (vm.music) "KJ Music" else "KJ Vídeos",
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.weight(1f)
            )
            val acc = vm.account
            if (acc == null) {
                OutlinedButton(onClick = { launcher.launch(gClient.signInIntent) }) { Text("Vincular conta Google") }
            } else {
                TextButton(onClick = {
                    gClient.signOut().addOnCompleteListener { vm.account = null }
                }) { Text("${acc.displayName ?: acc.email} • Sair") }
            }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            placeholder = { Text(if (vm.music) "Buscar músicas" else "Buscar vídeos") },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { vm.search(query) })
        )
        Spacer(Modifier.height(8.dp))

        val cur = vm.current
        if (cur != null) {
            if (!vm.music) {
                AndroidView(
                    modifier = Modifier.fillMaxWidth().height(220.dp),
                    factory = { c -> PlayerView(c).apply { player = vm.player } }
                )
            }
            Row(
                Modifier.fillMaxWidth().padding(vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(cur.title, maxLines = 2, overflow = TextOverflow.Ellipsis, color = Color.White)
                    Text(cur.author, color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                }
                if (vm.music) {
                    Button(onClick = { vm.togglePlay() }) { Text(if (vm.playing) "Pausar" else "Tocar") }
                }
            }
        }

        vm.loginMsg?.let { Text(it, color = Color.Gray, style = MaterialTheme.typography.bodySmall) }
        vm.error?.let { Text(it, color = Color(0xFFFF8A80), modifier = Modifier.padding(vertical = 4.dp)) }
        if (vm.loading) LinearProgressIndicator(Modifier.fillMaxWidth())

        LazyColumn(Modifier.fillMaxSize()) {
            items(vm.items) { item ->
                Row(
                    Modifier.fillMaxWidth().clickable { vm.play(item) }.padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AsyncImage(
                        model = item.thumb,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .then(if (vm.music) Modifier.size(64.dp) else Modifier.width(140.dp).height(80.dp))
                            .clip(RoundedCornerShape(8.dp))
                    )
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(item.title, maxLines = 2, overflow = TextOverflow.Ellipsis, color = Color.White)
                        Text(item.author, color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}
