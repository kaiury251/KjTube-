package com.kj.tube

import android.annotation.SuppressLint
import android.app.Application
import android.net.Uri
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class TubeVM(app: Application) : AndroidViewModel(app) {
    val music = BuildConfig.APP_MODE == "MUSIC"
    var items by mutableStateOf<List<Item>>(emptyList())
    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var current by mutableStateOf<Item?>(null)
    var playing by mutableStateOf(false)
    var loggedIn by mutableStateOf(false)
    var showLogin by mutableStateOf(false)

    val player: ExoPlayer = ExoPlayer.Builder(app)
        .setMediaSourceFactory(
            DefaultMediaSourceFactory(
                DefaultHttpDataSource.Factory()
                    .setUserAgent("Mozilla/5.0 (Windows NT 10.0; rv:128.0) Gecko/20100101 Firefox/128.0")
                    .setAllowCrossProtocolRedirects(true)
            )
        ).build()

    init {
        Session.load(app)
        loggedIn = Session.cookie != null
        Repo.init()
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onPlayerError(e: PlaybackException) {
                error = "Erro no player: ${e.errorCodeName}"
            }
        })
        search(if (music) "músicas mais tocadas" else "em alta brasil")
    }

    fun onLoginDone(cookie: String?) {
        showLogin = false
        if (cookie != null) {
            Session.save(getApplication(), cookie)
            loggedIn = true
            error = null
            current?.let { play(it) }
        }
    }

    fun logout() {
        CookieManager.getInstance().removeAllCookies(null)
        Session.save(getApplication(), null)
        loggedIn = false
    }

    fun search(q: String) {
        if (q.isBlank()) return
        viewModelScope.launch {
            loading = true; error = null
            try {
                items = withContext(Dispatchers.IO) { Repo.search(q, music) }
            } catch (e: Exception) {
                error = "Erro na busca: ${e.message}"
            }
            loading = false
        }
    }

    fun play(item: Item) {
        current = item
        viewModelScope.launch {
            error = null
            try {
                val r = withContext(Dispatchers.IO) { Repo.resolve(item.url, music) }
                val mi = MediaItem.Builder().setUri(r.url).apply {
                    if (r.hls) setMimeType(MimeTypes.APPLICATION_M3U8)
                }.build()
                player.setMediaItem(mi)
                player.prepare()
                player.playWhenReady = true
            } catch (e: Exception) {
                val m = e.message ?: ""
                error = if (m.contains("bot", true) || m.contains("LOGIN_REQUIRED"))
                    (if (loggedIn) "O YouTube não aceitou a sessão salva. Toque em \"Sair\", vincule a conta de novo e tente outra música."
                     else "O YouTube pediu login para esta rede. Toque em \"Vincular conta Google\" e entre na sua conta.")
                else "Não foi possível reproduzir: $m"
            }
        }
    }

    fun togglePlay() { if (player.isPlaying) player.pause() else player.play() }

    override fun onCleared() { player.release() }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val music = BuildConfig.APP_MODE == "MUSIC"
            val accent = if (music) Color(0xFFB388FF) else Color(0xFFFF3D3D)
            MaterialTheme(colorScheme = darkColorScheme(primary = accent)) {
                Surface(Modifier.fillMaxSize(), color = Color(0xFF0F0F0F)) {
                    val vm: TubeVM = viewModel()
                    if (vm.showLogin) LoginScreen(vm) else TubeScreen(vm)
                }
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun LoginScreen(vm: TubeVM) {
    BackHandler { vm.onLoginDone(null) }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Entre na sua conta Google", color = Color.White, modifier = Modifier.weight(1f))
            TextButton(onClick = { vm.onLoginDone(null) }) { Text("Cancelar") }
        }
        AndroidView(modifier = Modifier.fillMaxSize(), factory = { c ->
            WebView(c).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.userAgentString =
                    "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
                CookieManager.getInstance().setAcceptCookie(true)
                CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView, url: String?) {
                        val host = url?.let { Uri.parse(it).host } ?: return
                        if (host.endsWith("youtube.com")) {
                            val ck = CookieManager.getInstance().getCookie("https://www.youtube.com")
                            if (ck != null && ck.contains("SAPISID=")) vm.onLoginDone(ck)
                        }
                    }
                }
                loadUrl("https://accounts.google.com/ServiceLogin?service=youtube&hl=pt-BR&continue=https%3A%2F%2Fwww.youtube.com%2F")
            }
        })
    }
}

@Composable
fun TubeScreen(vm: TubeVM) {
    var query by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().statusBarsPadding().padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                if (vm.music) "KJ Music" else "KJ Vídeos",
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.weight(1f)
            )
            if (!vm.loggedIn) {
                OutlinedButton(onClick = { vm.showLogin = true }) { Text("Vincular conta Google") }
            } else {
                TextButton(onClick = { vm.logout() }) { Text("Conta vinculada • Sair") }
            }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            placeholder = { Text(if (vm.music) "Buscar músicas" else "Buscar vídeos") },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { vm.search(query) })
        )
        Spacer(Modifier.height(8.dp))

        val cur = vm.current
        if (cur != null) {
            if (!vm.music) {
                AndroidView(
                    modifier = Modifier.fillMaxWidth().height(220.dp),
                    factory = { c -> PlayerView(c).apply { player = vm.player } }
                )
            }
            Row(
                Modifier.fillMaxWidth().padding(vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(cur.title, maxLines = 2, overflow = TextOverflow.Ellipsis, color = Color.White)
                    Text(cur.author, color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                }
                if (vm.music) {
                    Button(onClick = { vm.togglePlay() }) { Text(if (vm.playing) "Pausar" else "Tocar") }
                }
            }
        }

        vm.error?.let { Text(it, color = Color(0xFFFF8A80), modifier = Modifier.padding(vertical = 4.dp)) }
        if (vm.loading) LinearProgressIndicator(Modifier.fillMaxWidth())

        LazyColumn(Modifier.fillMaxSize()) {
            items(vm.items) { item ->
                Row(
                    Modifier.fillMaxWidth().clickable { vm.play(item) }.padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AsyncImage(
                        model = item.thumb,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .then(if (vm.music) Modifier.size(64.dp) else Modifier.width(140.dp).height(80.dp))
                            .clip(RoundedCornerShape(8.dp))
                    )
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(item.title, maxLines = 2, overflow = TextOverflow.Ellipsis, color = Color.White)
                        Text(item.author, color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}
