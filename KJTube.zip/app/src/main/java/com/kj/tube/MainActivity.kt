package com.kj.tube

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class MainActivity : Activity() {
    private val music get() = BuildConfig.APP_MODE == "MUSIC"
    private val accent get() = if (music) Color.rgb(180, 135, 255) else Color.rgb(255, 65, 75)
    private val scopes = listOf(Scope("https://www.googleapis.com/auth/youtube.readonly"), Scope("https://www.googleapis.com/auth/youtube"))
    private var accessToken: String? = null
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var status: TextView
    private var player: WebView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(12, 12, 16)
        window.navigationBarColor = Color.rgb(12, 12, 16)
        buildShell(); showHome()
    }

    private fun buildShell() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(12,12,16)); setPadding(20,18,20,12) }
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextView(this).apply { text = if (music) "KJ MUSIC" else "KJ VÍDEOS"; textSize=23f; setTextColor(accent); setTypeface(null,1) }, LinearLayout.LayoutParams(0,-2,1f))
        header.addView(TextView(this).apply { text="Google"; textSize=14f; setTextColor(Color.WHITE); setPadding(16,10,16,10); setBackgroundColor(Color.rgb(38,38,48)); setOnClickListener { if(accessToken==null) connectGoogle() else showAccount() } })
        root.addView(header)
        status = TextView(this).apply { text="Sua biblioteca em um só lugar"; textSize=12f; setTextColor(Color.LTGRAY); setPadding(0,8,0,12) }
        root.addView(status)
        content = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { addView(content) }, LinearLayout.LayoutParams(-1,0,1f))
        val nav = LinearLayout(this).apply { gravity=Gravity.CENTER; setPadding(0,12,0,4) }
        listOf("Início","Explorar","Biblioteca","Conta").forEach { label ->
            nav.addView(TextView(this).apply { text=label; textSize=13f; gravity=Gravity.CENTER; setTextColor(Color.WHITE); setPadding(10,12,10,12); setOnClickListener { when(label){"Início"->showHome();"Explorar"->showSearch();"Biblioteca"->showLibrary();else->showAccount()} } }, LinearLayout.LayoutParams(0,-2,1f))
        }
        root.addView(nav); setContentView(root)
    }

    private fun reset(title:String, subtitle:String?=null) {
        player?.destroy(); player=null; content.removeAllViews(); text(title,22f,Color.WHITE,true)
        if(subtitle!=null) text(subtitle,13f,Color.LTGRAY)
    }
    private fun text(value:String,size:Float=15f,color:Int=Color.WHITE,bold:Boolean=false) {
        content.addView(TextView(this).apply { text=value; textSize=size; setTextColor(color); if(bold)setTypeface(null,1); setPadding(0,8,0,8) })
    }
    private fun button(label:String, action:()->Unit) {
        content.addView(Button(this).apply { text=label; isAllCaps=false; setOnClickListener { action() } }, LinearLayout.LayoutParams(-1,-2).apply { topMargin=8; bottomMargin=6 })
    }
    private fun showHome() {
        reset(if(music) "Descubra músicas" else "O que vamos assistir?", "Experiência KJ com navegação própria")
        if(accessToken==null) { text("Conecte sua conta Google para carregar seus dados do YouTube.",14f); button("Vincular conta Google"){connectGoogle()} }
        else { text("Conta conectada. Explore ou sincronize sua biblioteca."); button("Buscar conteúdo"){showSearch()}; button("Minha biblioteca"){showLibrary()} }
        text("Dica",18f,Color.WHITE,true); text("Use Explorar para pesquisar no catálogo oficial.",13f,Color.LTGRAY)
    }
    private fun showSearch() {
        reset("Explorar","Pesquisa no catálogo oficial do YouTube")
        val field=EditText(this).apply { hint=if(music) "Buscar músicas, artistas ou vídeos" else "Buscar vídeos"; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE); setSingleLine(true); setBackgroundColor(Color.rgb(34,34,43)); setPadding(14,8,14,8) }
        content.addView(field,LinearLayout.LayoutParams(-1,-2)); button("Pesquisar"){val q=field.text.toString().trim();if(q.isNotEmpty())search(q)}
    }
    private fun search(q:String) {
        val key=BuildConfig.YOUTUBE_API_KEY
        if(key.isBlank()){reset("Configuração necessária","Adicione YOUTUBE_API_KEY ao gradle.properties para habilitar a pesquisa.");return}
        reset("Resultados","Pesquisando: $q")
        apiGet("search?part=snippet&type=video&maxResults=20&q=${enc(q)}&key=${enc(key)}"){json->
            val items=json.optJSONArray("items");if(items==null||items.length()==0){text("Nenhum resultado encontrado.");return@apiGet}
            for(i in 0 until items.length()){val item=items.getJSONObject(i);val id=item.optJSONObject("id")?.optString("videoId")?:continue;val sn=item.optJSONObject("snippet")?:JSONObject();resultCard(sn.optString("title"),sn.optString("channelTitle"),id)}
        }
    }
    private fun resultCard(title:String,channel:String,id:String) {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL;setPadding(12,10,12,10);setBackgroundColor(Color.rgb(28,28,36)) }
        box.addView(TextView(this).apply{text=title;setTextColor(Color.WHITE);textSize=15f});box.addView(TextView(this).apply{text=channel;setTextColor(Color.LTGRAY);textSize=12f});box.setOnClickListener{play(id,title)}
        content.addView(box,LinearLayout.LayoutParams(-1,-2).apply{topMargin=6;bottomMargin=6})
    }
    private fun play(videoId:String,title:String) {
        content.removeAllViews();text(title,18f,Color.WHITE,true)
        val w=WebView(this);player=w;w.settings.javaScriptEnabled=true;w.settings.domStorageEnabled=true;w.webChromeClient=WebChromeClient();w.webViewClient=WebViewClient();content.addView(w,LinearLayout.LayoutParams(-1,230))
        val html="""<!doctype html><html><body style="margin:0;background:#000"><iframe width="100%" height="230" src="https://www.youtube-nocookie.com/embed/$videoId?playsinline=1" title="KJ Player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe></body></html>"""
        w.loadDataWithBaseURL("https://www.youtube-nocookie.com",html,"text/html","UTF-8",null);button("Voltar à pesquisa"){showSearch()}
    }
    private fun showLibrary() {
        reset("Minha biblioteca","Conteúdo autorizado da sua conta Google")
        if(accessToken==null){text("Vincule sua conta para sincronizar playlists, inscrições e vídeos curtidos.");button("Vincular conta Google"){connectGoogle()};return}
        button("Playlists"){loadEndpoint("playlists?part=snippet,contentDetails&mine=true&maxResults=50","Playlists")}
        button("Inscrições"){loadEndpoint("subscriptions?part=snippet&mine=true&maxResults=50","Inscrições")}
        button("Vídeos curtidos"){loadEndpoint("videos?part=snippet&myRating=like&maxResults=50","Vídeos curtidos")}
    }
    private fun loadEndpoint(path:String,heading:String) {
        reset(heading,"Sincronizando com o YouTube Data API")
        apiGet(path){json->val items=json.optJSONArray("items");if(items==null||items.length()==0){text("Nenhum item disponível.");return@apiGet};for(i in 0 until items.length()){val sn=items.getJSONObject(i).optJSONObject("snippet")?:JSONObject();text("• "+sn.optString("title",sn.optString("channelTitle","Item")),14f)}}
    }
    private fun showAccount() {
        reset("Conta","Gerencie a conexão com o Google");text(if(accessToken==null)"Nenhuma conta conectada." else "Conta Google autorizada nesta sessão.")
        if(accessToken==null)button("Conectar com Google"){connectGoogle()}else button("Desconectar"){accessToken=null;status.text="Conta desconectada";showAccount()}
        text("Permissões solicitadas: leitura de playlists, inscrições e vídeos curtidos.",13f,Color.LTGRAY)
    }
    private fun connectGoogle() {
        val request=AuthorizationRequest.builder().setRequestedScopes(scopes).build()
        Identity.getAuthorizationClient(this).authorize(request).addOnSuccessListener{result->
            if(result.hasResolution()){try{startIntentSenderForResult(result.pendingIntent!!.intentSender,7001,null,0,0,0)}catch(e:Exception){showError("Não foi possível abrir a autorização: ${e.message}")}}
            else{accessToken=result.accessToken;status.text="Conta Google conectada";showHome()}
        }.addOnFailureListener{showError("Falha na autorização Google: ${it.message}")}
    }
    @Deprecated("Deprecated in Java") override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==7001&&resultCode==Activity.RESULT_OK&&data!=null){try{val result=Identity.getAuthorizationClient(this).getAuthorizationResultFromIntent(data);accessToken=result.accessToken;status.text="Conta Google conectada";showHome()}catch(e:Exception){showError("Autorização não concluída: ${e.message}")}}
    }
    private fun apiGet(path:String,done:(JSONObject)->Unit) {
        val token=accessToken;if(token==null){showError("Conecte sua conta Google primeiro.");return}
        Thread{try{val conn=URL("https://www.googleapis.com/youtube/v3/$path").openConnection() as HttpURLConnection;conn.setRequestProperty("Authorization","Bearer $token");conn.connectTimeout=15000;conn.readTimeout=15000;val code=conn.responseCode;val stream=if(code in 200..299)conn.inputStream else conn.errorStream;val json=JSONObject(stream.bufferedReader().use{it.readText()});runOnUiThread{if(code !in 200..299)showError(json.optJSONObject("error")?.optString("message")?:"Erro da API")else done(json)};conn.disconnect()}catch(e:Exception){runOnUiThread{showError("Erro de conexão: ${e.message}")}}}.start()
    }
    private fun showError(message:String){Toast.makeText(this,message,Toast.LENGTH_LONG).show();status.text=message}
    private fun enc(s:String)=URLEncoder.encode(s,"UTF-8")
    override fun onDestroy(){player?.destroy();super.onDestroy()}
}
