# KJ Vídeos e KJ Music

Um só projeto, dois apps (flavors): `videos` (KJ Vídeos) e `music` (KJ Music).

- Interface própria (busca, listas, histórico) — não mostra o site do YouTube.
- Os dados (busca e histórico) vêm da API interna do YouTube / YouTube Music usando a sessão da conta vinculada.
- O vídeo/áudio toca no player do YouTube dentro de uma área do app, com bloqueio de anúncios
  (bloqueio de requisições + script que pula anúncios).
- "Vincular conta Google": login do Google dentro do app; não precisa configurar nada no Google Cloud.
- Histórico: aba "Histórico", com "Carregar mais" para ir paginando até o fim.

## Compilar
`gradle assembleVideosDebug assembleMusicDebug` (ou use o build.yml no GitHub).
