# KJ Vídeos e KJ Music

Um só projeto, dois apps (flavors): `videos` (KJ Vídeos) e `music` (KJ Music).
Sem anúncios: os streams são extraídos direto da fonte (NewPipeExtractor).

## Vincular conta Google
O botão usa o Login com Google. Para funcionar no seu APK:
1. Google Cloud Console > APIs e serviços > Credenciais > criar "ID do cliente OAuth" tipo Android.
2. Pacotes: `com.kj.videos` e `com.kj.music` (um cliente para cada).
3. SHA-1: o da chave debug do build (veja o log do Gradle `signingReport`, ou o APK do Releases).
4. Configure a tela de consentimento OAuth.
Sem isso aparece "código 10". Obs.: o login mostra nome/e-mail; sincronizar inscrições e playlists exigiria a YouTube Data API.

## Compilar
`gradle assembleVideosDebug assembleMusicDebug` (ou use o build.yml no GitHub).
