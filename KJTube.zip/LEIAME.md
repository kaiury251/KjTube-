# KJ Vídeos e KJ Music

Um só projeto, dois apps (flavors): `videos` (KJ Vídeos, m.youtube.com) e `music` (KJ Music, music.youtube.com).
O app abre o site do YouTube dentro de um WebView com bloqueio de anúncios
(bloqueio de requisições de anúncio + script que pula/oculta anúncios).

## Vincular conta Google
O botão abre o login do Google dentro do app. A sessão fica salva no WebView.
Toque em "Sair" para apagar a sessão. Não precisa configurar nada no Google Cloud.

## Compilar
`gradle assembleVideosDebug assembleMusicDebug` (ou use o build.yml no GitHub).
