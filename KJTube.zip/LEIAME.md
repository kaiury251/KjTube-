# KJ Vídeos + KJ Music — interface nativa (base de integração)

Este projeto gera dois aplicativos Android a partir do mesmo código:

- `videosDebug` → KJ Vídeos (`com.kj.videos`)
- `musicDebug` → KJ Music (`com.kj.music`)

## O que mudou

- A navegação principal agora é nativa e própria; não abre a página inicial do YouTube.
- Login/autorização Google usa a API de autorização do Google Identity Services, com consentimento de escopos.
- Integração inicial com YouTube Data API para pesquisar vídeos e consultar playlists, inscrições e vídeos curtidos.
- Player integrado à tela do app usando o player oficial incorporado do YouTube (IFrame), sem carregar a página inteira do YouTube.
- KJ Vídeos e KJ Music mantêm cores e identificadores de aplicativo separados.

## Configuração obrigatória no Google Cloud

1. Crie um projeto no Google Cloud Console.
2. Ative **YouTube Data API v3**.
3. Configure a tela de consentimento OAuth e os usuários de teste, se o app estiver em teste.
4. Crie uma chave de API e restrinja-a à YouTube Data API v3.
5. Cadastre os clientes OAuth Android para os pacotes `com.kj.videos` e `com.kj.music`, usando o SHA-1 do certificado com que o APK será assinado.
6. Coloque a chave no `gradle.properties` (não publique essa chave no repositório):

```properties
YOUTUBE_API_KEY=SUA_CHAVE_DA_API
```

A autorização OAuth precisa ser configurada para os dois IDs de pacote. Para publicar, use certificado de assinatura próprio e cadastre o SHA-1 correspondente no Google Cloud.

## Compilar

```bash
gradle assembleVideosDebug assembleMusicDebug
```

Os APKs de debug ficam em `app/build/outputs/apk/` nas pastas `videos/debug` e `music/debug`.

## Limitações importantes das APIs oficiais

- A API oficial não fornece o histórico de visualizações do YouTube nem o histórico de reprodução do YouTube Music. Portanto, esta versão não consegue importar esses históricos automaticamente.
- O catálogo do YouTube Music não tem uma API pública equivalente para reproduzir todo o serviço Music. A pesquisa implementada consulta vídeos do YouTube; resultados musicais podem aparecer como vídeos/áudios publicados na plataforma.
- A API retorna playlists, inscrições e vídeos curtidos dentro dos escopos e permissões concedidos, respeitando as cotas e regras do Google.
- O player incorporado é o player oficial do YouTube. O aplicativo não tenta remover, ocultar ou pular anúncios do player; a presença de anúncios e a disponibilidade de reprodução são determinadas pelo YouTube e pelos direitos do conteúdo.
- O token de acesso fica apenas em memória durante a execução atual. Fechar o app exige nova autorização quando o Google solicitar. Uma implementação de produção deve adicionar gerenciamento seguro de sessão/renovação e tratamento de paginação da API.

Este ZIP é o código-fonte atualizado, não APKs já compilados. É necessário configurar as credenciais do seu projeto Google Cloud antes de testar a sincronização real.
