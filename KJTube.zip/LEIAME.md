# KJ Vídeos e KJ Music

Um só projeto, dois apps (flavors): `videos` (KJ Vídeos) e `music` (KJ Music).
Sem anúncios: os streams são extraídos direto da fonte (NewPipeExtractor).

## Vincular conta Google
O botão abre o login do Google dentro do app (WebView). Ao entrar, o app guarda a sessão
do YouTube e a usa nas requisições, o que resolve o bloqueio
"Sign in to confirm you're not a bot". Não precisa configurar nada no Google Cloud.
Toque em "Sair" para apagar a sessão.

## Compilar
`gradle assembleVideosDebug assembleMusicDebug` (ou use o build.yml no GitHub).
